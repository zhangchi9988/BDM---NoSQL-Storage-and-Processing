-- drop table students;
-- drop table courses;
-- drop table departments;

create table students
(
	student_id	number(8) primary key,
	last_name	varchar2(20),
	first_name	varchar2(25) not null,
	email		varchar2(8) not null,
	phone_number	varchar2(20),
	CGA		number(4,2),
	department_id	varchar2(4) not null,
	admission_date	date,
	course_id	varchar2(7)
);

create table courses
(
	course_code	varchar2(7) primary key,
	department_id	varchar2(4) not null,
	name	varchar2(40),
	instructor	varchar2(30) not null
);

create table departments
(
	department_id	varchar2(4) primary key,
	name	varchar2(40),
	room_number	number(4)	
);

insert into students values (03456789, 'Porter', 'Harry', 'cs_phx', 23581234, 10.50, 'COMP','2004-12-01', 'COMP231');
insert into students values (05456734, 'Da Vinci', 'Leonardo', 'cs_dvl', 23585678, 12.00, 'COMP', '1498-09-01','COMP231');
insert into students values (03456221, 'Greenleaf', 'Legolas', 'ma_glx', 23582468, 9.12, 'MATH','2011-09-03', 'ELEC214');
insert into students values (04567890, NULL, 'Ceaser', 'ee_cxx', 23589876, 8.34, 'ELEC', '1973-09-13','MATH246');
insert into students values (99987654, 'Lazy', 'Lazy', 'lz_llx', 23581357, 2.55, 'LAZY', '2014-08-12',NULL);

insert into courses values ('COMP231', 'COMP', 'Database System', 'Prof. Papadias and Prof. Chen');
insert into courses values ('COMP303', 'COMP', 'Web Programming', 'Prof. Rossiter');
insert into courses values ('ELEC214', 'ELEC', 'Electronics', 'Prof. Man');
insert into courses values ('MATH246', 'MATH', 'Probability', 'Prof. Hui');
insert into courses values ('HUMA123', 'HUMA', 'What is Human', 'Prof. White');


insert into departments values ('COMP', 'Computer Science', '3528');
insert into departments values ('MATH', 'Mathematics', '3461');
insert into departments values ('ELEC', 'Electronic Engineering', '2528');
insert into departments values ('FINA', 'Finance', '4654');
insert into departments values ('LANG', 'Language', '5434');



